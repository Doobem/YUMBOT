/* YUMBOT — Application Logic v3.0 */
const S={p:2,c:'beginner',diets:[],alls:[],star:0,plan:null};
const DAYS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const SLBLS=['','😕 Not great','😐 It was okay','🙂 Pretty good','😊 Really liked it','🤩 Absolutely loved it!'];

/* ═══ DIET GROUPS ═══ */
const DG={
'🌱 Plant-Based':['Vegan','Vegetarian','Pescatarian','Flexitarian'],
'🚫 Avoid Ingredients':['Gluten-Free','Dairy-Free','Egg-Free','Nut-Free','Soy-Free','Shellfish-Free','Fish-Free','Corn-Free','Sesame-Free','Nightshade-Free'],
'🕌 Cultural & Religious':['Halal','Kosher','Jain','Indian Vegetarian'],
'🌍 World Cuisines':['Mediterranean','East Asian','West African','Middle Eastern','Latin American','Caribbean','Eastern European','Nordic'],
'💪 Health & Fitness':['High-Protein','High-Fibre','Keto','Low-Carb','Low-Fat','Low-Calorie','High-Calorie','Athlete','Muscle-Building'],
'🏥 Medical Diets':['Low-FODMAP','Diabetic-Friendly','Heart-Healthy','Kidney-Friendly','Anti-Inflammatory','Autoimmune Protocol','Low-Histamine','Low-Purine','Low-Sodium','Low-Sugar','Coeliac-Safe','Lactose-Intolerant','PKU-Safe'],
'🍽️ Eating Styles':['Paleo','Whole30','Raw Food','DASH Diet','MIND Diet'],
'👨‍👩‍👧 Life Stage':['Baby-Toddler','Kids','Teen-Friendly','Senior-Friendly','Pregnancy-Safe','Post-Surgery Soft'],
'⏱️ Lifestyle':['Budget-Friendly','Student Meals','One-Pot Meals','5-Ingredient Meals','Meal-Prep']};
const ALLS=['Gluten','Dairy','Eggs','Peanuts','Tree Nuts','Soy','Fish','Shellfish','Sesame','Mustard','Celery','Lupin','Molluscs','Sulphites'];

/* ═══ RECIPES — CSS art colours + emoji + YouTube links ═══ */
const R={
breakfast:[
{n:'Creamy Blueberry Porridge',t:10,d:'Easy',c:'British',hot:false,
 tags:['Vegetarian','High-Fibre'],emoji:'🥣',
 bg:'linear-gradient(160deg,#1A0D2E,#0D1A2E,#0A0D1A)',glow:'#4466FF',
 vid:{title:'Jamie Oliver – Perfect Porridge',url:'https://www.youtube.com/watch?v=LCmSEUe0s38'},
 ing:['100g rolled oats','400ml whole milk','100g fresh blueberries','1 tbsp honey','Pinch of salt'],
 steps:['Bring milk to a gentle simmer in a saucepan.','Add oats and salt, stir constantly 4–5 minutes until thick and creamy.','Spoon into bowls, top with blueberries and drizzle with honey.']},

{n:'Avocado Toast & Poached Egg',t:10,d:'Easy',c:'Modern',hot:false,
 tags:['Vegetarian'],emoji:'🥑',
 bg:'linear-gradient(160deg,#0A1A0D,#152B0A,#0D200A)',glow:'#44FF66',
 vid:{title:'Bon Appétit – Perfect Poached Eggs',url:'https://www.youtube.com/watch?v=I-V0oHx3OJM'},
 ing:['2 slices sourdough','1 ripe avocado','2 large eggs','Lemon juice','Chilli flakes','Salt and pepper'],
 steps:['Toast bread until golden and crisp.','Mash avocado with lemon juice, salt, and pepper.','Poach eggs 3 minutes in simmering water. Lay on toast, add chilli flakes.']},

{n:'Shakshuka',t:25,d:'Easy',c:'Middle Eastern',hot:true,
 tags:['Vegetarian','Gluten-Free'],emoji:'🍳',
 bg:'linear-gradient(160deg,#2B0A0A,#3D1A0A,#1A0D0A)',glow:'#FF4400',
 vid:{title:'Sip and Feast – Shakshuka',url:'https://www.youtube.com/watch?v=rMaRQakAgXI'},
 ing:['4 large eggs','2×400g tins chopped tomatoes','1 red pepper','1 onion','3 garlic cloves','1 tsp cumin','1 tsp smoked paprika','Fresh coriander'],
 steps:['Fry onion, pepper, and garlic in olive oil for 5 minutes.','Add spices and tomatoes. Simmer 10 minutes until thick.','Make 4 wells, crack in eggs, cover until whites set. Top with coriander.']},

{n:'Overnight Chia Pudding',t:5,d:'Easy',c:'Modern',hot:false,
 tags:['Vegan','Gluten-Free','Dairy-Free'],emoji:'🫙',
 bg:'linear-gradient(160deg,#0A0A2B,#1A0A2B,#0A151A)',glow:'#00AAFF',
 vid:{title:'Pick Up Limes – Chia Pudding',url:'https://www.youtube.com/watch?v=x_JJQlPt4sY'},
 ing:['3 tbsp chia seeds','200ml oat milk','1 tsp vanilla','1 tbsp maple syrup','Seasonal fruit to top'],
 steps:['Mix chia seeds, oat milk, vanilla, and maple syrup in a jar.','Refrigerate overnight for at least 6 hours.','Stir in the morning and top with fresh fruit.']},

{n:'Keto Bacon & Eggs',t:10,d:'Easy',c:'British',hot:true,
 tags:['Keto','Low-Carb','Gluten-Free'],emoji:'🥓',
 bg:'linear-gradient(160deg,#1A0A0A,#2B1A0A,#0A0A0A)',glow:'#FF8800',
 vid:{title:'Joshua Weissman – Perfect Bacon & Eggs',url:'https://www.youtube.com/watch?v=qolnFxGJxTQ'},
 ing:['3 rashers smoked back bacon','2 large eggs','½ ripe avocado','Knob of butter','Salt and pepper'],
 steps:['Fry bacon in a hot pan until the edges are crisp.','Melt butter in the same pan, cook eggs sunny-side up.','Serve alongside sliced avocado and cracked black pepper.']},

{n:'Vegan Smoothie Bowl',t:5,d:'Easy',c:'Modern',hot:false,
 tags:['Vegan','Gluten-Free'],emoji:'🍓',
 bg:'linear-gradient(160deg,#2B0A1A,#1A0A2B,#0A1A0A)',glow:'#FF2277',
 vid:{title:'Rainbow Plant Life – Smoothie Bowls',url:'https://www.youtube.com/watch?v=66Ai6lQJ6bA'},
 ing:['1 frozen banana','½ cup frozen mango','100ml oat milk','2 tbsp granola','1 tbsp chia seeds','Fresh strawberries'],
 steps:['Blend banana, mango, and oat milk until thick — it should hold a spoon.','Pour into a chilled bowl.','Top with granola, chia seeds, and strawberries.']}
],
lunch:[
{n:'Vegan Chickpea Curry',t:30,d:'Easy',c:'Indian',hot:true,
 tags:['Vegan','Gluten-Free','High-Protein','Halal'],emoji:'🍛',
 bg:'linear-gradient(160deg,#2B1A0A,#3D2A0A,#1A1A0A)',glow:'#FFAA00',
 vid:{title:'Minimalist Baker – Chickpea Curry',url:'https://www.youtube.com/watch?v=aWlsomPyO0Q'},
 ing:['2×400g tins chickpeas','400g tin chopped tomatoes','400ml tin coconut milk','1 onion','4 garlic cloves','2 tsp curry powder','1 tsp turmeric','Coriander and rice'],
 steps:['Fry onion and garlic until golden, about 7 minutes.','Add spices, fry 2 minutes. Add tomatoes, coconut milk, chickpeas.','Simmer 20 minutes. Serve over rice with coriander.']},

{n:'Spiced Lentil Soup',t:30,d:'Easy',c:'Middle Eastern',hot:true,
 tags:['Vegan','Gluten-Free','High-Protein'],emoji:'🍲',
 bg:'linear-gradient(160deg,#2B1A0A,#1A0A0A,#1A1A00)',glow:'#FF6600',
 vid:{title:'Ethan Chlebowski – Lentil Soup',url:'https://www.youtube.com/watch?v=uFmWJXeyNtw'},
 ing:['200g red lentils','400g tin chopped tomatoes','1 litre vegetable stock','1 onion','2 garlic cloves','1 tsp cumin','½ tsp turmeric','Lemon and parsley'],
 steps:['Fry onion and garlic. Add spices, cook 1 minute.','Add lentils, tomatoes, and stock. Simmer 25 minutes.','Squeeze in lemon, season, and top with parsley.']},

{n:'Falafel Wrap',t:20,d:'Easy',c:'Middle Eastern',hot:false,
 tags:['Vegan','High-Protein','Halal'],emoji:'🌯',
 bg:'linear-gradient(160deg,#1A1A0A,#2B2A0A,#0A1A0A)',glow:'#AAFF00',
 vid:{title:'Tasty – Crispy Falafel Wrap',url:'https://www.youtube.com/watch?v=rKV5q3zRCio'},
 ing:['8 falafels','2 large flatbreads','4 tbsp hummus','Baby gem lettuce','2 tomatoes','Tahini sauce and lemon'],
 steps:['Heat falafels at 200°C for 8 minutes until crisp.','Warm flatbreads in a dry pan 30 seconds each side.','Spread hummus, add salad, falafel, drizzle tahini and lemon.']},

{n:'Paneer Tikka Wrap',t:25,d:'Medium',c:'Indian',hot:true,
 tags:['Vegetarian','High-Protein'],emoji:'🫓',
 bg:'linear-gradient(160deg,#2B0A1A,#3D1A0A,#1A0A0A)',glow:'#FF4400',
 vid:{title:'Chef Ranveer Brar – Paneer Tikka',url:'https://www.youtube.com/watch?v=XIJW5vLo1ZA'},
 ing:['250g paneer, cubed','2 flatbreads','150g yogurt','1 tsp each cumin, turmeric, garam masala','Cucumber, fresh mint, lemon'],
 steps:['Mix half the yogurt with spices. Coat paneer. Marinate 15 minutes.','Grill on highest heat 3–4 minutes each side until charred.','Stir cucumber and mint into remaining yogurt. Serve in wraps with raita.']},

{n:'West African Groundnut Soup',t:40,d:'Medium',c:'West African',hot:true,
 tags:['Vegan','Gluten-Free','Halal'],emoji:'🥜',
 bg:'linear-gradient(160deg,#2B1A00,#3D2A00,#1A0A00)',glow:'#FFAA00',
 vid:{title:'Precious Core – Groundnut Soup',url:'https://www.youtube.com/watch?v=LKVkXWuupDY'},
 ing:['3 tbsp peanut butter','2 sweet potatoes, cubed','400g tin chopped tomatoes','1 litre veg stock','1 onion','1 tsp chilli flakes','Fresh coriander'],
 steps:['Fry onion and garlic until golden. Add sweet potato, tomatoes, stock, chilli.','Simmer 25 minutes until potato is very tender.','Stir in peanut butter until dissolved. Top with coriander.']},

{n:'Tuna Niçoise Salad',t:20,d:'Easy',c:'French',hot:false,
 tags:['Gluten-Free','Pescatarian'],emoji:'🥗',
 bg:'linear-gradient(160deg,#0A1A0A,#0A1A1A,#0A0A1A)',glow:'#00AAFF',
 vid:{title:'Internet Shaquille – Niçoise Salad',url:'https://www.youtube.com/watch?v=3X7fGp-PPXQ'},
 ing:['2×145g tins tuna in olive oil','2 large eggs','150g fine green beans','4 small new potatoes','Kalamata olives','Dijon, olive oil, red wine vinegar'],
 steps:['Boil potatoes 12 mins, add eggs for last 7. Blanch beans 3 mins.','Whisk 1 tsp Dijon, 2 tbsp oil, 1 tbsp vinegar. Season well.','Arrange everything in bowls and drizzle with dressing.']}
],
dinner:[
{n:'Baked Salmon & Roasted Veg',t:30,d:'Easy',c:'Modern',hot:true,
 tags:['Pescatarian','Gluten-Free','High-Protein','Keto'],emoji:'🐟',
 bg:'linear-gradient(160deg,#0A1A2B,#0A2B1A,#1A1A2B)',glow:'#00FFAA',
 vid:{title:'Pro Home Cooks – Baked Salmon',url:'https://www.youtube.com/watch?v=ZAqf6WZG_qc'},
 ing:['2×180g salmon fillets','1 courgette, 1 red pepper, 1 red onion','Olive oil, lemon, fresh dill','Sea salt and pepper'],
 steps:['Preheat oven to 200°C. Roast chopped veg in oil for 10 minutes.','Nestle salmon among veg, season, add lemon slices.','Roast 12–15 minutes until salmon flakes easily. Scatter with dill.']},

{n:'Chicken Tikka Masala',t:40,d:'Medium',c:'Indian',hot:true,
 tags:['Gluten-Free','High-Protein','Halal'],emoji:'🍗',
 bg:'linear-gradient(160deg,#2B0A0A,#3D1A0A,#1A0A1A)',glow:'#FF4400',
 vid:{title:'Ethan Chlebowski – Tikka Masala',url:'https://www.youtube.com/watch?v=a03U45jFxOI'},
 ing:['600g chicken breast, cubed','400g tin chopped tomatoes','150ml double cream','1 onion','4 garlic cloves','2 tbsp tikka masala paste','Coriander and rice'],
 steps:['Coat chicken in tikka paste. Grill until charred in places, about 8 minutes.','Fry onion and garlic until deeply golden. Add tomatoes, simmer 10 minutes.','Pour in cream, stir in chicken. Simmer 10 minutes. Serve with rice.']},

{n:'One-Pot Mushroom Risotto',t:35,d:'Medium',c:'Italian',hot:true,
 tags:['Vegetarian','Gluten-Free','One-Pot'],emoji:'🍄',
 bg:'linear-gradient(160deg,#1A1A0A,#2B2A1A,#0A1A0A)',glow:'#AAFF44',
 vid:{title:'Ethan Chlebowski – Mushroom Risotto',url:'https://www.youtube.com/watch?v=HKKqBM_GNAs'},
 ing:['300g mixed mushrooms','200g arborio rice','1 litre warm veg stock','1 glass white wine','1 shallot, 2 garlic cloves','50g parmesan, 30g cold butter','Fresh parsley'],
 steps:['Fry shallot until soft. Add mushrooms, cook until golden.','Add rice, stir 1 minute. Pour in wine, stir until absorbed.','Add stock ladle by ladle, stirring 18–20 mins. Beat in butter and parmesan.']},

{n:'Caribbean Jerk Chicken',t:50,d:'Medium',c:'Caribbean',hot:true,
 tags:['Gluten-Free','High-Protein','Halal'],emoji:'🍖',
 bg:'linear-gradient(160deg,#2B0A00,#3D1500,#1A0800)',glow:'#FF6600',
 vid:{title:'Smokin & Grillin – Jerk Chicken',url:'https://www.youtube.com/watch?v=SFe04VqPRY4'},
 ing:['4 chicken leg quarters','3 tbsp jerk seasoning paste','Juice of 2 limes','Olive oil, fresh thyme','Rice and peas to serve'],
 steps:['Score chicken deeply. Rub all over with jerk paste and lime. Marinate 1+ hour.','Roast at 200°C for 40–45 minutes until deeply caramelised.','Rest 5 minutes. Serve with rice and peas.']},

{n:'Pasta Aglio e Olio',t:15,d:'Easy',c:'Italian',hot:true,
 tags:['Vegetarian','Budget-Friendly','5-Ingredient'],emoji:'🍝',
 bg:'linear-gradient(160deg,#1A1A00,#2B2B00,#0A0A00)',glow:'#FFEE00',
 vid:{title:'Joshua Weissman – Aglio e Olio',url:'https://www.youtube.com/watch?v=Ful-8rE4Yxc'},
 ing:['200g spaghetti','6 garlic cloves, thinly sliced','5 tbsp extra virgin olive oil','1 tsp chilli flakes','Handful flat-leaf parsley'],
 steps:['Cook spaghetti until al dente. Reserve 150ml pasta water.','Warm oil. Gently fry garlic on lowest heat until just golden — don\'t burn it.','Add chilli, pasta, pasta water. Toss vigorously. Add parsley and serve immediately.']},

{n:'Golden Turmeric Soup',t:30,d:'Easy',c:'Modern',hot:true,
 tags:['Vegan','Gluten-Free','Anti-Inflammatory'],emoji:'🌟',
 bg:'linear-gradient(160deg,#2B1A00,#3D2800,#1A1000)',glow:'#FFAA00',
 vid:{title:'Well Plated – Golden Turmeric Soup',url:'https://www.youtube.com/watch?v=nYi5ViJlmR4'},
 ing:['150g red lentils','400ml tin coconut milk','1 litre veg stock','2 tsp turmeric','1 tbsp fresh ginger','1 onion, 2 garlic cloves','Lemon, coriander, black pepper'],
 steps:['Fry onion, garlic, ginger. Add turmeric and plenty of black pepper.','Add lentils, stock, and coconut milk. Simmer 20 minutes.','Blend smooth. Stir in lemon juice. Top with coriander.']},

{n:'Black Bean Tacos',t:20,d:'Easy',c:'Mexican',hot:false,
 tags:['Vegan','Gluten-Free','Budget-Friendly'],emoji:'🌮',
 bg:'linear-gradient(160deg,#0A1A0A,#1A2B00,#1A1A00)',glow:'#AAFF00',
 vid:{title:'Binging with Babish – Street Tacos',url:'https://www.youtube.com/watch?v=xX9JKhHm1pA'},
 ing:['2×400g tins black beans','8 corn tortillas','1 ripe avocado','2 tomatoes, diced','1 lime, 1 tsp cumin, 1 tsp paprika','Fresh coriander and jalapeño'],
 steps:['Fry beans with cumin and paprika 5 minutes until slightly caramelised.','Dice tomatoes, coriander, jalapeño, squeeze lime — make salsa.','Warm tortillas. Fill with beans, avocado, and salsa.']}
]};

/* ═══ TAG COLOUR ═══ */
function tc(t){if(['Vegan','Vegetarian'].includes(t))return 'tg';if(['Halal','Kosher'].includes(t))return 'ty';if(t.includes('Free')||t==='Keto'||t==='One-Pot')return 'tp';return 'tr'}

/* ═══ FOOD ART CARD (CSS only, no images) ═══ */
function artPanel(r,h='200'){
  const steam=r.hot?`<div class="csteam"><div class="cw cw1"></div><div class="cw cw2"></div><div class="cw cw3"></div></div>`:'';
  return`<div class="fart" style="height:${h}px">
    <div class="bg" style="background:${r.bg}"></div>
    <div class="gring" style="background:${r.glow}"></div>
    <div class="food-emoji" style="font-size:${parseInt(h)*.18}rem">${r.emoji}</div>
    ${steam}
  </div>`;
}

/* ═══ NAV ═══ */
function show(p){
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));
  document.querySelectorAll('.nb').forEach(b=>b.classList.remove('on'));
  document.getElementById('page-'+p).classList.add('active');
  if(p==='plan'&&!S.plan)buildPlan();
  if(p==='shopping')buildShop();
  document.getElementById('nav').classList.remove('open');
  window.scrollTo({top:0,behavior:'smooth'});
}

/* ═══ HOME ═══ */
function buildHomeGrid(){
  const g=document.getElementById('home-grid');
  const picks=[R.breakfast[2],R.lunch[0],R.dinner[1],R.dinner[2]];
  g.innerHTML=picks.map(r=>{
    const tags=r.tags.slice(0,2).map(t=>`<span class="mtag ${tc(t)}">${t}</span>`).join('');
    return`<div class="mc" onclick='showRecipe(${JSON.stringify(r)})'>
      ${artPanel(r)}
      <div class="mtags">${tags}</div>
      <div class="mc-body">
        <div class="mc-cuis">${r.c}</div>
        <div class="mc-name">${r.n}</div>
        <div class="mc-meta"><span>⏱ ${r.t} mins</span><span>· ${r.d}</span></div>
      </div>
    </div>`;
  }).join('');
}
function buildDPBand(){
  document.getElementById('dp-band').innerHTML=Object.values(DG).flat().map(d=>`<span class="dp">${d}</span>`).join('');
}

/* ═══ WIZARD ═══ */
function nxt(n){
  document.querySelectorAll('.wst').forEach(s=>s.classList.remove('active'));
  document.getElementById('ws'+n).classList.add('active');
  ['wp1','wp2','wp3'].forEach((id,i)=>{
    const el=document.getElementById(id);el.classList.remove('on','done');
    if(i+1===n)el.classList.add('on');else if(i+1<n)el.classList.add('done');
  });
  if(n===2)buildDG();if(n===3)buildAG();
  window.scrollTo({top:100,behavior:'smooth'});
}
function setP(n,btn){S.p=n;document.querySelectorAll('#pr .cb').forEach(b=>b.classList.remove('on'));btn.classList.add('on')}
function setC(c,btn){S.c=c;document.querySelectorAll('#cfr .cb').forEach(b=>b.classList.remove('on'));btn.classList.add('on')}
function buildDG(){let h='';for(const[g,items]of Object.entries(DG)){h+=`<span class="gl">${g}</span>`;items.forEach(d=>{const s=S.diets.includes(d)?'sel':'';h+=`<button class="dc ${s}" onclick="togD('${d}',this)">${d}</button>`;});}document.getElementById('dg').innerHTML=h}
function togD(d,btn){S.diets=S.diets.includes(d)?S.diets.filter(x=>x!==d):[...S.diets,d];btn.classList.toggle('sel',S.diets.includes(d))}
function buildAG(){document.getElementById('ag').innerHTML=ALLS.map(a=>{const s=S.alls.includes(a)?'sel':'';return`<button class="ac ${s}" onclick="togA('${a}',this)">${a}</button>`;}).join('')}
function togA(a,btn){S.alls=S.alls.includes(a)?S.alls.filter(x=>x!==a):[...S.alls,a];btn.classList.toggle('sel',S.alls.includes(a))}
function saveP(){toast('Preferences saved! Building your plan… 🍳');S.plan=null;setTimeout(()=>show('plan'),500)}

/* ═══ PLAN ═══ */
function pick(arr,ex=[]){const p=arr.filter(r=>!ex.includes(r.n));return p[Math.floor(Math.random()*p.length)]||arr[0]}
function buildPlan(){
  const plan={};const ub=[],ul=[],ud=[];
  DAYS.forEach(day=>{
    const b=pick(R.breakfast,ub),l=pick(R.lunch,ul),d=pick(R.dinner,ud);
    ub.push(b.n);ul.push(l.n);ud.push(d.n);plan[day]={breakfast:b,lunch:l,dinner:d};
  });
  S.plan=plan;renderDesk(plan);renderMob(plan);
}
function miniArt(r){
  const steam=r.hot?`<div class="ssteam"><div class="ssw ssw1"></div><div class="ssw ssw2"></div><div class="ssw ssw3"></div></div>`:'';
  return`<div class="sfart" style="background:${r.bg}">${r.emoji}${steam}</div>`;
}
function renderDesk(plan){
  document.getElementById('pgrid').innerHTML=Object.entries(plan).map(([day,meals])=>`
    <div class="dcol"><div class="dh">${day.slice(0,3)}</div>
    ${['breakfast','lunch','dinner'].map(tp=>{const m=meals[tp];return`
      <div class="mslot" onclick='showRecipe(${JSON.stringify(m)})'>
        ${miniArt(m)}
        <div class="stype">${tp}</div>
        <div class="sname">${m.n}</div>
        <div class="stime">⏱ ${m.t}m</div>
        <button class="swbtn" onclick="swp(event,'${day}','${tp}')">🔄</button>
      </div>`;}).join('')}
    </div>`).join('');
}
function renderMob(plan){
  document.getElementById('mobplan').innerHTML=Object.entries(plan).map(([day,meals])=>`
    <div class="mday"><div class="mdh">${day}</div>
    ${['breakfast','lunch','dinner'].map(tp=>{const m=meals[tp];return`
      <div class="mmeal" onclick='showRecipe(${JSON.stringify(m)})'>
        <div class="mfart" style="background:${m.bg}">${m.emoji}</div>
        <div style="flex:1;min-width:0">
          <div class="mtype">${tp}</div>
          <div class="mname">${m.n}</div>
          <div class="mtime">⏱ ${m.t} mins · ${m.d}</div>
        </div>
        <button class="mswap" onclick="swp(event,'${day}','${tp}')">🔄</button>
      </div>`;}).join('')}
    </div>`).join('');
}
function swp(e,day,tp){
  e.stopPropagation();
  const pool=R[tp],cur=S.plan[day][tp].n;
  const opts=pool.filter(r=>r.n!==cur);
  S.plan[day][tp]=opts[Math.floor(Math.random()*opts.length)];
  renderDesk(S.plan);renderMob(S.plan);
  toast(`Swapped your ${tp} for ${day} 🔄`);
}

/* ═══ RECIPE ═══ */
function showRecipe(r){
  show('recipe');
  const tags=r.tags.map(t=>`<span class="mtag ${tc(t)}" style="font-size:.61rem">${t}</span>`).join(' ');
  const ings=(r.ing||[]).map(i=>`<li>${i}</li>`).join('');
  const steps=(r.steps||[]).map(s=>`<li>${s}</li>`).join('');
  const rsteam=r.hot?`<div class="rsteam"><div class="rs rs1"></div><div class="rs rs2"></div><div class="rs rs3"></div><div class="rs rs4"></div><div class="rs rs5"></div></div>`:'';

  document.getElementById('rcontent').innerHTML=`
    <div class="rhero">
      <div class="rg" style="background:${r.bg};filter:brightness(1.3)"></div>
      <div class="remoji" style="font-size:8rem">${r.emoji}</div>
      <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(7,3,10,.6) 0%,transparent 60%)"></div>
      ${rsteam}
    </div>
    <h1 class="rtitle">${r.n}</h1>
    <div style="display:flex;gap:.52rem;flex-wrap:wrap;margin:.72rem 0 1.4rem">${tags}</div>
    <div class="rpills">
      <div class="rpill"><strong>⏱ ${r.t} mins</strong>Cook time</div>
      <div class="rpill"><strong>${r.d}</strong>Difficulty</div>
      <div class="rpill"><strong>🌍 ${r.c}</strong>Cuisine</div>
    </div>
    <div class="rl">
      <div><div class="rth">What you'll need</div><ul class="il">${ings}</ul></div>
      <div><div class="rth">How to make it</div><ol class="sl">${steps}</ol></div>
    </div>
    ${r.vid?`<div class="vsec">
      <div class="vth">Watch how to make it 🎬</div>
      <p class="vsub">Click the card below to watch the full step-by-step video on YouTube</p>
      <a class="vcard" href="${r.vid.url}" target="_blank" rel="noopener">
        <div class="vplay">▶</div>
        <div class="vtxt">
          <h4>${r.n} — Full Recipe Video</h4>
          <p>${r.vid.title}</p>
          <span class="vtag">Watch on YouTube ↗</span>
        </div>
      </a>
    </div>`:''}`;
}

/* ═══ SHOPPING ═══ */
const SMAP={'🥦 Fresh Produce':['lettuce','tomato','carrot','onion','garlic','spinach','broccoli','courgette','pepper','mushroom','cucumber','avocado','lemon','lime','ginger','basil','coriander','parsley','spring onion','leek','celery','kale','sweet potato','potato','pea','green bean','strawberry','blueberry','chilli','jalapeño','thyme'],'🥩 Meat & Fish':['chicken','beef','pork','lamb','fish','salmon','tuna','cod','haddock','prawn','shrimp','crab','mince','sausage','bacon','ham','steak','fillet','mackerel'],'🧀 Dairy & Eggs':['milk','cheese','butter','cream','yogurt','egg','feta','mozzarella','cheddar','parmesan','ricotta','paneer'],'🥫 Tins & Jars':['chickpea','lentil','bean','black bean','kidney bean','coconut milk','chopped tomato','tomato paste','pesto','tahini','peanut butter','soy sauce','fish sauce','olive','stock','curry paste','jerk paste','hummus'],'🌾 Dry Goods':['pasta','spaghetti','rice','flour','oats','bread','noodle','quinoa','couscous','sugar','salt','pepper','cumin','paprika','turmeric','curry powder','cinnamon','oil','olive oil','vinegar','chia seeds','granola','flatbread','corn tortilla','arborio','chilli flakes'],'🧊 Frozen':['frozen pea','frozen corn','frozen spinach','frozen berry']};
function categ(item){const l=item.toLowerCase();for(const[s,kws]of Object.entries(SMAP)){if(kws.some(k=>l.includes(k)))return s}return'🛍️ Other'}
function buildShop(){
  const el=document.getElementById('shcontent');
  if(!S.plan){el.innerHTML=`<div style="text-align:center;padding:4rem;color:var(--mu)"><p style="font-size:1.05rem;margin-bottom:1rem">Build a meal plan first!</p><button class="bp" onclick="show('plan')">Build My Plan →</button></div>`;return}
  const seen=new Set(),list={};
  Object.values(S.plan).forEach(meals=>Object.values(meals).forEach(meal=>(meal.ing||[]).forEach(ing=>{
    const key=ing.toLowerCase().replace(/^[\d.\/\w]+\s*(g|ml|tsp|tbsp|tin|handful|pinch|litre|kg|oz|lb|cup|×|x)\s+/i,'').trim();
    if(!seen.has(key)){seen.add(key);const s=categ(ing);if(!list[s])list[s]=[];list[s].push(ing)}
  })));
  const order=[...Object.keys(SMAP),'🛍️ Other'];
  let html=`<p style="color:var(--mu);margin-bottom:1.5rem;font-size:.87rem">${seen.size} items for your 21 meals. Tick off as you go!</p>`;
  order.forEach(s=>{
    if(!list[s])return;
    html+=`<div class="shs"><div class="shsh">${s}</div>${list[s].map((item,i)=>`
      <div class="shi"><input type="checkbox" id="si${s.charAt(2)}${i}" onchange="strikeItem(this)"/><label for="si${s.charAt(2)}${i}" style="cursor:pointer;flex:1">${item}</label></div>`).join('')}</div>`;
  });
  el.innerHTML=html;
}
function strikeItem(cb){const l=cb.nextElementSibling;l.style.textDecoration=cb.checked?'line-through':'none';l.style.color=cb.checked?'var(--mu)':'var(--tx)'}

/* ═══ FEEDBACK ═══ */
function setStar(n){S.star=n;document.querySelectorAll('.star').forEach((s,i)=>s.classList.toggle('lit',i<n));document.getElementById('stlbl').textContent=SLBLS[n]||''}
function submitFB(){if(!S.star){toast('Please tap a star to rate first ⭐');return}document.getElementById('fbform').style.display='none';document.getElementById('fbthanks').style.display='block'}

/* ═══ TOAST ═══ */
function toast(msg){let t=document.querySelector('.toast');if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t)}t.textContent=msg;t.classList.add('show');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),3500)}

/* ═══ INIT ═══ */
document.addEventListener('DOMContentLoaded',()=>{buildHomeGrid();buildDPBand()});